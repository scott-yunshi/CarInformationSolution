﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CarsInformation.Application.Interfaces;
using CarsInformation.Core.Entities;
using CarsInformation.Core.Enums;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace CarsInformation.API.Controllers
{
    [Route("api/[controller]")]
    [EnableCors("Allow_CarsInformation.Front")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly ICarRepository _Car;

        public CarsController(ICarRepository Car)
        {
            _Car = Car;
        }

        [HttpGet] // api/cars
        public async Task<IEnumerable<Car>> GetCars()
        {
            return await _Car.Get();
        }

        [HttpGet("type/{type}")] // api/cars/type/{type}
        public async Task<IEnumerable<Car>> GetCars(string type)
        {
            var typeInputString = type.Trim();
            SellerType inpuType;

            //Validate input seller type
            if (!String.IsNullOrEmpty(typeInputString) &&
                Enum.TryParse(type.Trim(), out inpuType))
            {
                return await _Car.Get(inpuType);
            }
            else
            //Return empty array for invalid input
                return Enumerable.Empty<Car>();
        }
    }
}
