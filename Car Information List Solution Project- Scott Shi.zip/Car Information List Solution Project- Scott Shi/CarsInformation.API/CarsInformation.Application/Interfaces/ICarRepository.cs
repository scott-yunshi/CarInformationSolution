﻿using CarsInformation.Core.Entities;
using CarsInformation.Core.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarsInformation.Application.Interfaces
{
    public interface ICarRepository
    {
        Task<IEnumerable<Car>> Get();
        Task<IEnumerable<Car>> Get(SellerType type);
    }
}
