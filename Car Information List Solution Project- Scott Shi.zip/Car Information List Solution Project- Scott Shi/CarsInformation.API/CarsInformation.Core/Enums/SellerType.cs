﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsInformation.Core.Enums
{
    public enum SellerType
    {
        Private,
        Dealer
    }
}
