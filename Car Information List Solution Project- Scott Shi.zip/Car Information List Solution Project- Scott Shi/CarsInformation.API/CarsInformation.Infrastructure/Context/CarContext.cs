﻿using CarsInformation.Core.Entities;
using CarsInformation.Core.Enums;
using Microsoft.EntityFrameworkCore;

namespace CarsInformation.Infrastructure.Context
{
    public class CarContext : DbContext
    {
        public CarContext(DbContextOptions<CarContext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Car> Cars { get; set; }

        #region CarDataSeed
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Car>().HasData(
                new Car
                {
                    Id = 1,
                    Make = "Mazda",
                    Model = "CX-5",
                    Price = 28000,
                    TypeOfSeller = SellerType.Dealer
                },
                new Car
                {
                    Id = 2,
                    Make = "Toyota",
                    Model = "Corolla",
                    Price = 18000,
                    TypeOfSeller = SellerType.Dealer
                },
                new Car
                {
                    Id = 3,
                    Make = "BMW",
                    Model = "X3",
                    Price = 55000,
                    TypeOfSeller = SellerType.Private
                },
                new Car
                {
                    Id = 4,
                    Make = "Honda",
                    Model = "Civic",
                    Price = 23000,
                    TypeOfSeller = SellerType.Private
                },
                new Car
                {
                    Id = 5,
                    Make = "Audi",
                    Model = "A3",
                    Price = 40000,
                    TypeOfSeller = SellerType.Dealer
                },
                new Car
                {
                    Id = 6,
                    Make = "Mazda",
                    Model = "CX-3",
                    Price = 19800,
                    TypeOfSeller = SellerType.Private
                },
                new Car
                {
                    Id = 7,
                    Make = "Mitsubishi",
                    Model = "ASX",
                    Price = 36700,
                    TypeOfSeller = SellerType.Dealer
                },
                new Car
                {
                    Id = 8,
                    Make = "Toyota",
                    Model = "RAV4",
                    Price = 33500,
                    TypeOfSeller = SellerType.Dealer
                },
                new Car
                {
                    Id = 9,
                    Make = "Audi",
                    Model = "TT",
                    Price = 36600,
                    TypeOfSeller = SellerType.Dealer
                }
            );
        }
        #endregion
    }
}
