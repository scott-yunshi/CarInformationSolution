﻿using CarsInformation.Application.Interfaces;
using CarsInformation.Infrastructure.Context;
using CarsInformation.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace CarsInformation.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<ICarRepository, CarRepository>();
            services.AddDbContext<CarContext>(opt => opt.UseInMemoryDatabase("cars"));
            return services;
        }
    }
}
