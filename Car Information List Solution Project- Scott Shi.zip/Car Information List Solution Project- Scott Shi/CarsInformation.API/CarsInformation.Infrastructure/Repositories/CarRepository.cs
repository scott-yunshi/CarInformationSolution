﻿using CarsInformation.Application.Interfaces;
using CarsInformation.Core.Entities;
using CarsInformation.Core.Enums;
using CarsInformation.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarsInformation.Infrastructure.Repositories
{
    public class CarRepository : ICarRepository
    {
        private readonly CarContext _context;

        public CarRepository(CarContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Car>> Get()
        {
            //return all car information in list
            return await _context.Cars.ToListAsync();
        }

        public async Task<IEnumerable<Car>> Get(SellerType type)
        {
            //return car information in list based on seller type
            return await _context.Cars.Where(c => c.TypeOfSeller.CompareTo(type)==0).ToListAsync();
        }
    }
}
