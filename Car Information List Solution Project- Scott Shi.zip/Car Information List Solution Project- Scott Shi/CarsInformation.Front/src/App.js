import React, { useState, useEffect } from 'react';
import CarListTable from './CarListTable';


function App() {
  const [data, setData] = useState([]);

  //When seller type changed, fetch data again
  useEffect(() => {
    loadByType('');
  }, []);

  const loadByType = (type) => {
    fetch('https://localhost:44383/api/cars/' + type)
      .then(res => res.json())
      .then((r) => {
        setData(r);
      })
      .catch(console.log);
  };

  return (
    <div>
      <CarListTable carData={data} loadByType={loadByType} />
    </div>
  );
}

export default App;

