import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';
import IconButton from '@material-ui/core/IconButton';
import TablePagination from '@material-ui/core/TablePagination';
import { TYPE_OF_SELLER } from './constant';

//Custom table styles
const useStyles = makeStyles({
  carTable: {
    minWidth: 600,
  },
  selector: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 20,
    marginRight: 60,
    marginBottom: 60,
  },
  typeSelectorSpace: {
    paddingRight: 8,
  },
  widthSelector: {
    width: 80,
  },
});

const sortData = (dataArray, direction = 'asc') => {
  const isAsc = (direction === 'asc' ? 1 : -1);
  dataArray.sort(function(a, b) {
    return isAsc * (a.price - b.price);
  });
};

export default function CarListTable({ carData, loadByType }) {
  const classes = useStyles();
  const [sort, setSort] = useState('asc');
  const [data, setData] = useState([]);
  const [type, setType] = useState(' ');
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [page, setPage] = React.useState(0);

  useEffect(() => {
    sortData(carData);
    setData(carData);
  },[carData]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSort = () => {
    if (sort === 'asc') {
      setSort('desc');
      sortData(data, 'desc');
    } else {
      setSort('asc');
      sortData(data, 'asc');
    }
  };

  //When seller type changed, reset paging setting
  const handleChange = (event) => {
    if (event.target.value === ' ') {
      loadByType('');
    } else {
      loadByType('type/' + event.target.value);
    }
    setType(event.target.value);
    setRowsPerPage(5);
    setPage(0);
  };

  return (
    <TableContainer component={Paper}>
      <Table className={classes.carTable} aria-label="table">
        <TableHead>
          <TableRow>
            {/* <TableCell align="center">ID</TableCell> */}
            <TableCell align="center">Make</TableCell>
            <TableCell align="center">Model</TableCell>
            <TableCell align="center">
              <span>Price&nbsp;(AU$)</span>
              <IconButton onClick={handleSort}>
                {sort === 'asc' ? (<ArrowUpwardIcon />) : (<ArrowDownwardIcon />)}
              </IconButton>
            </TableCell>
            <TableCell align="center">Type&nbsp;of&nbsp;Seller</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
            <TableRow key={row.id}>
              {/* <TableCell align="center">{row.id}</TableCell> */}
              <TableCell align="center">{row.make}</TableCell>
              <TableCell align="center">{row.model}</TableCell>
              <TableCell align="center">{row.price}</TableCell>
              <TableCell align="center">{TYPE_OF_SELLER[row.typeOfSeller]}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <div className={classes.selector}>
        <Typography className={classes.typeSelectorSpace}>Seller Type:</Typography>
        <Select
          value={type}
          onChange={handleChange}
          className={classes.widthSelector}
        >
          <MenuItem value=" ">All</MenuItem>
          <MenuItem value={0}>Private</MenuItem>
          <MenuItem value={1}>Dealer</MenuItem>
        </Select>
      </div>

      <TablePagination
          rowsPerPageOptions={[5, 10, 20]}
          component="div"
          count={data.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
        />
    </TableContainer>
  );
}