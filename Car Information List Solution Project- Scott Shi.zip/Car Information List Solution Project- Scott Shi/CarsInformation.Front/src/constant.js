export const TYPE_OF_SELLER = {
    0: 'Private',
    1: 'Dealer',
};
